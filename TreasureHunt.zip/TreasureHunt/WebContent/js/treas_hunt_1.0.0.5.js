
window.onload = init;
var socket;
var current_tab;

function sleep(ms) 
{
    return new Promise(resolve => setTimeout(resolve, ms));
}

function hideAllDiv()
{
	document.getElementById("login_div").style.display = "none";
	document.getElementById("question_div").style.display = "none";
	document.getElementById("error_div").style.display = "none";
	document.getElementById("menu_div").style.display = "none";
	document.getElementById("otp_div").style.display = "none";
	document.getElementById("end_game_div").style.display = "none";
	document.getElementById("session_expire_div").style.display = "none";
	document.getElementById("score_board_div").style.display = "none";
	document.getElementById("level_history_div").style.display = "none";	
	
}

function closeInfoDiv()
{
	document.getElementById("error_div").style.display = "none";
	document.getElementById("otp_div").style.display = "none";
}

function onMessage(event) {
    var pageJson = JSON.parse(event.data);
    
    if(pageJson.page === "LOGIN"){
    	init();
    }
    else if(pageJson.page === "QUES"){
    	hideAllDiv();
    	current_tab = "PLAY";
    	var element = document.getElementById("score_tab");
    	element.classList.remove("active");
    	element = document.getElementById("history_tab");
    	element.classList.remove("active");
    	element = document.getElementById("play_tab");
    	element.classList.add("active");
    	document.getElementById("question_div").style.display = '';
    	document.getElementById("menu_div").style.display = '';
    	document.getElementById("question_id").value=pageJson.level;
    	document.getElementById("ques_image").src=pageJson.source;
    	document.getElementById("lbl_level").innerHTML=pageJson.level;
    	document.getElementById("txt_answer_field").value = "";
    	document.getElementById("ans_submit_loading").style.display="none";
    	document.getElementById("btn_submit").style.display='';
    	if(pageJson.hint === "N")
    	{
    		document.getElementById("hint_div").style.display = "none";
    	}
    	else
    	{
    		document.getElementById("hint_div").style.display = '';
    		document.getElementById("hint_message").innerHTML = pageJson.hint;
    	}
    }
    else if(pageJson.page === "INCORRECTANSWER"){
    	hideAllDiv();
    	current_tab = "PLAY";
    	document.getElementById("question_div").style.display = '';
    	document.getElementById("menu_div").style.display = '';
    	document.getElementById("txt_answer_field").value = "";
    	alert("Wrong Answer, Better luck next time");
    	document.getElementById("ans_submit_loading").style.display="none";
    	document.getElementById("btn_submit").style.display='';
    }
    else if(pageJson.page === "LOGINERROR"){
    	current_tab = "";
    	hideAllDiv();
    	document.getElementById("login_div").style.display = '';
    	document.getElementById("error_div").style.display = '';
    	document.getElementById("error_div").innerHTML = pageJson.message + "<span><img src=\"images/cross.jpg\"  onclick=\"closeInfoDiv()\" id=\"close_link\"/></span>";
    	document.getElementById("lgn_submit_loading").style.display="none";
		document.getElementById("btn_submit_login").style.display='';
		document.getElementById("otp_loading").style.display="none";
		document.getElementById("otp_link").style.display='';
    }
    else if(pageJson.page === "SCOREBOARD")
    {
    	hideAllDiv();
    	current_tab = "BOARD";
    	document.getElementById("menu_div").style.display = '';
    	document.getElementById("score_board_div").style.display = '';
    	var team_value = pageJson.t1;
    	var res = team_value.split("@");
    	document.getElementById("team1_name").innerHTML = res[0];
    	document.getElementById("team1_level").innerHTML = res[1];
    	team_value = pageJson.t2;
    	res = team_value.split("@");
    	document.getElementById("team2_name").innerHTML = res[0];
    	document.getElementById("team2_level").innerHTML = res[1];
    	team_value = pageJson.t3;
    	res = team_value.split("@");
    	document.getElementById("team3_name").innerHTML = res[0];
    	document.getElementById("team3_level").innerHTML = res[1];
    	team_value = pageJson.t4;
    	res = team_value.split("@");
    	document.getElementById("team4_name").innerHTML = res[0];
    	document.getElementById("team4_level").innerHTML = res[1];
    	team_value = pageJson.t5;
    	res = team_value.split("@");
    	document.getElementById("team5_name").innerHTML = res[0];
    	document.getElementById("team5_level").innerHTML = res[1];
    	team_value = pageJson.t6;
    	if(team_value)
    	{
    		res = team_value.split("@");
        	document.getElementById("team6_name").innerHTML = res[0];
        	document.getElementById("team6_level").innerHTML = res[1];
    	}
    	document.getElementById("ans_submit_loading").style.display="none";
    	document.getElementById("btn_submit").style.display='';
    }
    
    else if(pageJson.page === "LEVELHISTORY")
    {
    	hideAllDiv();
    	current_tab = "HISTORY";
    	document.getElementById("menu_div").style.display = '';
    	document.getElementById("level_history_div").style.display = '';
    	
    	document.getElementById("level1_number").innerHTML = pageJson.L1;
    	document.getElementById("level1_clear_by").innerHTML = pageJson.CROSSBY1;
    	document.getElementById("level1_clear_date").innerHTML = pageJson.CROSSDATE1;
    	document.getElementById("level1_clear_time").innerHTML = pageJson.CROSSTIME1;
    	
    	document.getElementById("level2_number").innerHTML = pageJson.L2;
    	document.getElementById("level2_clear_by").innerHTML = pageJson.CROSSBY2;
    	document.getElementById("level2_clear_date").innerHTML = pageJson.CROSSDATE2;
    	document.getElementById("level2_clear_time").innerHTML = pageJson.CROSSTIME2;
    	
    	document.getElementById("level3_number").innerHTML = pageJson.L3;
    	document.getElementById("level3_clear_by").innerHTML = pageJson.CROSSBY3;
    	document.getElementById("level3_clear_date").innerHTML = pageJson.CROSSDATE3;
    	document.getElementById("level3_clear_time").innerHTML = pageJson.CROSSTIME3;
    	
    	document.getElementById("level4_number").innerHTML = pageJson.L4;
    	document.getElementById("level4_clear_by").innerHTML = pageJson.CROSSBY4;
    	document.getElementById("level4_clear_date").innerHTML = pageJson.CROSSDATE4;
    	document.getElementById("level4_clear_time").innerHTML = pageJson.CROSSTIME4;
    	
    	document.getElementById("level5_number").innerHTML = pageJson.L5;
    	document.getElementById("level5_clear_by").innerHTML = pageJson.CROSSBY5;
    	document.getElementById("level5_clear_date").innerHTML = pageJson.CROSSDATE5;
    	document.getElementById("level5_clear_time").innerHTML = pageJson.CROSSTIME5;
    	
    	document.getElementById("level6_number").innerHTML = pageJson.L6;
    	document.getElementById("level6_clear_by").innerHTML = pageJson.CROSSBY6;
    	document.getElementById("level6_clear_date").innerHTML = pageJson.CROSSDATE6;
    	document.getElementById("level6_clear_time").innerHTML = pageJson.CROSSTIME6;
    	
    	document.getElementById("level7_number").innerHTML = pageJson.L7;
    	document.getElementById("level7_clear_by").innerHTML = pageJson.CROSSBY7;
    	document.getElementById("level7_clear_date").innerHTML = pageJson.CROSSDATE7;
    	document.getElementById("level7_clear_time").innerHTML = pageJson.CROSSTIME7;
    	
    	document.getElementById("level8_number").innerHTML = pageJson.L8;
    	document.getElementById("level8_clear_by").innerHTML = pageJson.CROSSBY8;
    	document.getElementById("level8_clear_date").innerHTML = pageJson.CROSSDATE8;
    	document.getElementById("level8_clear_time").innerHTML = pageJson.CROSSTIME8;
    	
    	document.getElementById("level9_number").innerHTML = pageJson.L9;
    	document.getElementById("level9_clear_by").innerHTML = pageJson.CROSSBY9;
    	document.getElementById("level9_clear_date").innerHTML = pageJson.CROSSDATE9;
    	document.getElementById("level9_clear_time").innerHTML = pageJson.CROSSTIME9;
    	
    	document.getElementById("level10_number").innerHTML = pageJson.L10;
    	document.getElementById("level10_clear_by").innerHTML = pageJson.CROSSBY10;
    	document.getElementById("level10_clear_date").innerHTML = pageJson.CROSSDATE10;
    	document.getElementById("level10_clear_time").innerHTML = pageJson.CROSSTIME10;
    	
    	document.getElementById("ans_submit_loading").style.display="none";
    	document.getElementById("btn_submit").style.display='';
    }
    
    else if(pageJson.page === "OTPSENT"){
    	current_tab = "";
    	hideAllDiv();
    	document.getElementById("otp_div").style.display = '';
    	document.getElementById("login_div").style.display = '';
    	document.getElementById("otp_div").innerHTML = pageJson.message + "<span><img src=\"images/cross.jpg\"  onclick=\"closeInfoDiv()\" id=\"close_link\"/></span>";
    	document.getElementById("otp_loading").style.display="none";
		document.getElementById("otp_link").style.display='';
    	
    }
    else if(pageJson.page === "ENDPAGE")
    {
    	hideAllDiv();
    	current_tab = "PLAY";
    	document.getElementById("ans_submit_loading").style.display="none";
    	document.getElementById("btn_submit").style.display='';
    	document.getElementById("menu_div").style.display = '';
    	document.getElementById("end_game_div").style.display = '';
    }
    else if(pageJson.page === "SESSIONEXPIRED")
    {
    	document.getElementById("ans_submit_loading").style.display="none";
    	document.getElementById("btn_submit").style.display='';
    	sessionExpire();
    }
    else if(pageJson.page === "LOGOUT")
    {
    	init();
    }
}

function init() {
	hideAllDiv();
	current_tab = "";
	document.getElementById("login_div").style.display = '';
	document.getElementById("txt_user_name").value = '';
	document.getElementById("txt_team_password").value = '';
	document.getElementById("txt_user_otp").value = '';
	document.getElementById("lgn_submit_loading").style.display="none";
	document.getElementById("btn_submit_login").style.display='';
	document.getElementById("otp_loading").style.display="none";
	document.getElementById("otp_link").style.display='';
	document.getElementById("ans_submit_loading").style.display="none";
	document.getElementById("btn_submit").style.display='';
}
function sessionExpire()
{
	hideAllDiv();
	current_tab = "";
	document.getElementById("session_expire_div").style.display = '';
}

function PlayArea()
{
	if(socket.readyState == 0 || socket.readyState == 2 || socket.readyState == 3)
	{
		sessionExpire();
		return;
	}
	if(current_tab === "PLAY")
	{
		return;
	}
	var element = document.getElementById("score_tab");
	element.classList.remove("active");
	element = document.getElementById("history_tab");
	element.classList.remove("active");
	element = document.getElementById("play_tab");
	element.classList.add("active");
	current_tab = "PLAY";
	var DeviceAction = 
	{
		action: "play_area"
	};	
	socket.send(JSON.stringify(DeviceAction));
}

function ScoreBoard()
{
	if(socket.readyState == 0 || socket.readyState == 2 || socket.readyState == 3)
	{
		sessionExpire();
		return;
	}
	if(current_tab === "BOARD")
	{
		return;
	}
	var element = document.getElementById("play_tab");
	element.classList.remove("active");
	element = document.getElementById("history_tab");
	element.classList.remove("active");
	element = document.getElementById("score_tab");
	element.classList.add("active");
	current_tab = "BOARD";
	var DeviceAction = 
	{
		action: "score_board"
	};	
	socket.send(JSON.stringify(DeviceAction));
}

function Logout()
{
	if(socket.readyState == 0 || socket.readyState == 2 || socket.readyState == 3)
	{
		sessionExpire();
		return;
	}
	var DeviceAction = 
	{
		action: "logout"
	};	
	socket.send(JSON.stringify(DeviceAction));
}

async function getUserOTP()
{
	var counter = 0;
	var email_id = document.getElementById("txt_user_name").value;
	if(email_id == null || email_id == "")
		alert("Enter registered email_id to get the OTP");
	else
	{
		document.getElementById("otp_link").style.display="none";
		document.getElementById("otp_loading").style.display = '';
		//socket = new WebSocket("ws://vp-3c2xoafc105:8011/TreasureHunt/actions");
		socket = new WebSocket("ws://dev34.visionplus.io:8080/TreasureHunt/actions");
		socket.onmessage = onMessage;
		while(true)
		{
			counter++;
			if(socket.readyState == 1)
			{
				break;
			}
			await sleep(1000);
			if(counter == 10)
			{
				break;
			}	
		}
		if(counter != 10)
		{
			var DeviceAction = 
			{
				action: "get_otp",
				user_email: email_id
			};	
			socket.send(JSON.stringify(DeviceAction));
		}
		else
		{
			alert("Not able to establish the  connection");
			document.getElementById("otp_loading").style.display="none";
			document.getElementById("otp_link").style.display='';
		}
	}
}

function LevelHistory()
{
	if(socket.readyState == 0 || socket.readyState == 2 || socket.readyState == 3)
	{
		sessionExpire();
		return;
	}
	if(current_tab === "HISTORY")
	{
		return;
	}
	var element = document.getElementById("play_tab");
	element.classList.remove("active");
	var element = document.getElementById("score_tab");
	element.classList.remove("active");
	element = document.getElementById("history_tab");
	element.classList.add("active");
	current_tab = "HISTORY";
	var DeviceAction = 
	{
		action: "level_history"
	};	
	socket.send(JSON.stringify(DeviceAction));
}

function submitAnswer()
{
	if(socket.readyState == 0 || socket.readyState == 2 || socket.readyState == 3)
	{
		sessionExpire();
		return;
	}
	var question_id = document.getElementById("question_id").value;
	var user_answer = document.getElementById("txt_answer_field").value;
	if(user_answer == null || user_answer == "")
	{
		alert("Enter the answer to cross this level");
		return;
	}
	document.getElementById("btn_submit").style.display="none";
	document.getElementById("ans_submit_loading").style.display='';
	var DeviceAction = {
	    action: "submit_answer",
	    question_id : question_id,
	    user_answer: user_answer
    };	
	socket.send(JSON.stringify(DeviceAction));
}

function loginAgain()
{
	init();	
}

async function checkLogin()
{
	var counter = 0;
	current_tab = "";
	var user_name = document.getElementById("txt_user_name").value;
	if(user_name == null || user_name == "")
	{
		alert("Enter registered email_id");
		return;
	}	
	var team_password = document.getElementById("txt_team_password").value;
	if(team_password == null || team_password == "")
	{
		alert("Enter your team password");
		return;
	}
	var user_otp = document.getElementById("txt_user_otp").value;
	if(user_otp == null || user_otp == "")
	{
		alert("Enter your otp to login");
		return;
	}
	var LoginAction = {
        action: "login",
        user_name: user_name,
        team_password: team_password,
        user_otp: user_otp
    };
	document.getElementById("btn_submit_login").style.display="none";
	document.getElementById("lgn_submit_loading").style.display='';
	//socket = new WebSocket("ws://vp-3c2xoafc105:8011/TreasureHunt/actions");
	socket = new WebSocket("ws://dev34.visionplus.io:8080/TreasureHunt/actions");
	socket.onmessage = onMessage;
	while(true)
	{
		counter++;
		if(socket.readyState == 1)
		{
			break;
		}
		await sleep(1000);
		if(counter == 10)
		{
			break;
		}	
	}
	if(counter != 10)
	{
		socket.send(JSON.stringify(LoginAction));
	}
	else
	{
		alert("Not able to establish the  connection");
		document.getElementById("lgn_submit_loading").style.display="none";
		document.getElementById("btn_submit_login").style.display='';
	}
}












