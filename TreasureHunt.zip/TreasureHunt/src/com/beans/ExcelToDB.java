package com.beans;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelToDB
{
  public static void main(String[] args)
  {

    String excelFilePath = "C:/data/TreasureUsers/USERINFO.xlsx";

    int batchSize = 100;

    Connection connection = null;

    try
    {

      // Create Workbook instance holding reference to .xlsx file
      // XSSFWorkbook workbook = new XSSFWorkbook(file);

      // Get first/desired sheet from the workbook
      // XSSFSheet sheet = workbook.getSheetAt(0);

      long start = System.currentTimeMillis();

      FileInputStream inputStream = new FileInputStream(excelFilePath);
      XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
      // Workbook workbook = new XSSFWorkbook(inputStream);

      Sheet firstSheet = workbook.getSheetAt(0);
      Iterator<Row> rowIterator = firstSheet.iterator();

      connection = StorageConnection.getNewStorageConnection();

      String sql = "INSERT INTO USERINFO(first_name, last_name, email_id, otp, team_id, status) VALUES(?, ?, ?, ?, ?,?)";
      PreparedStatement statement = connection.prepareStatement(sql);

      int count = 0;

      // rowIterator.next(); // skip the header row

      while (rowIterator.hasNext())
      {
        Row nextRow = rowIterator.next();
        Iterator<Cell> cellIterator = nextRow.cellIterator();

        while (cellIterator.hasNext())
        {
          Cell nextCell = cellIterator.next();
          int columnIndex = nextCell.getColumnIndex();

          switch (columnIndex)
          {
            case 0:
              String first_name = nextCell.getStringCellValue();
              statement.setString(1, first_name.trim().toUpperCase());
              break;
            case 1:
              String last_name = nextCell.getStringCellValue();
              statement.setString(2, last_name.trim().toUpperCase());
              break;
            case 2:
              String email_id = nextCell.getStringCellValue();
              statement.setString(3, email_id.trim().toLowerCase());
              break;
            case 4:
              int team_id = (int) nextCell.getNumericCellValue();
              statement.setInt(5, team_id);
          }

        }
        statement.setString(4, "");
        statement.setString(6, "OFF");
        statement.executeUpdate();
      }
      // connection.close();
      workbook.close();
      long end = System.currentTimeMillis();
      System.out.printf("Import done in %d ms\n", (end - start));

    }
    catch (IOException ex1)
    {
      System.out.println("Error reading file");
      ex1.printStackTrace();
    }
    catch (SQLException ex2)
    {
      System.out.println("Database error");
      ex2.printStackTrace();
    }

  }
}
