package com.beans;

public class Question
{
  private String quesId;
  private String questionSrc;
  private String questionAnswer;
  private String questionHint;

  public String getQuesId()
  {
    return quesId;
  }

  public void setQuesId(String quesId)
  {
    this.quesId = quesId;
  }

  public String getQuestionSrc()
  {
    return questionSrc;
  }

  public void setQuestionSrc(String questionSrc)
  {
    this.questionSrc = questionSrc;
  }

  public String getQuestionAnswer()
  {
    return questionAnswer;
  }

  public void setQuestionAnswer(String questionAnswer)
  {
    this.questionAnswer = questionAnswer;
  }

  public String getQuestionHint()
  {
    return questionHint;
  }

  public void setQuestionHint(String questionHint)
  {
    this.questionHint = questionHint;
  }

}
