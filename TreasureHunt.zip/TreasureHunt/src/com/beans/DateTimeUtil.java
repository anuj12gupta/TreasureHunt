package com.beans;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public abstract class DateTimeUtil
{
  public static String getServerDate()
  {
    Calendar calendar = Calendar.getInstance();
    Date date = new Date(calendar.getTime().getTime());
    return date.toString();
  }

  public static String getServerTime()
  {
    Calendar calendar = Calendar.getInstance();
    SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
    return format.format(calendar.getTime());
  }

  public static void main(String args[]) throws Exception
  {

    System.out.println(getServerDate());

    // String cur_time = getServerTime(); System.out.println(cur_time.compareTo("15:00:00"));

    /*
     * String REQ_TIME = "17:59:59"; String SYS_UP_TIME = "11:00:00"; String SYS_DOWN_TIME = "17:00:00";
     * 
     * SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss"); java.util.Date date1 = format.parse(REQ_TIME); java.util.Date date2 = format.parse(SYS_UP_TIME); java.util.Date date3 =
     * format.parse(SYS_DOWN_TIME); long up_difference = date2.getTime() - date1.getTime(); long down_difference = date3.getTime() - date1.getTime(); long st_diff = up_difference / 1000; long dt_diff
     * = down_difference / 1000; System.out.println((up_difference / 1000) + "     " + (down_difference / 1000));
     * 
     * if (st_diff <= 0 && dt_diff >= 0) { System.out.println("REQ IS VALID"); } else System.out.println("WINDOW IS CLOSED");
     */

    /*
     * JSONObject object = new JSONObject(); object.put("name", "sample"); JSONArray array = new JSONArray();
     * 
     * JSONObject arrayElementOne = new JSONObject(); arrayElementOne.put("setId", 1); JSONArray arrayElementOneArray = new JSONArray();
     * 
     * JSONObject arrayElementOneArrayElementOne = new JSONObject(); arrayElementOneArrayElementOne.put("name", "ABC"); arrayElementOneArrayElementOne.put("type", "STRING");
     * 
     * JSONObject arrayElementOneArrayElementTwo = new JSONObject(); arrayElementOneArrayElementTwo.put("name", "XYZ"); arrayElementOneArrayElementTwo.put("type", "STRING");
     * 
     * arrayElementOneArray.put(arrayElementOneArrayElementOne); arrayElementOneArray.put(arrayElementOneArrayElementTwo);
     * 
     * arrayElementOne.put("setDef", arrayElementOneArray); array.put(arrayElementOne); object.put("def", array);
     */
  }

}
