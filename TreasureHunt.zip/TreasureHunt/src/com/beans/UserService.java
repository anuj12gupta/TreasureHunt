package com.beans;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class UserService
{
  private Connection connection;

  public UserService(Connection connection)
  {
    this.connection = connection;
  }

  public boolean checkUserLogin(String user_name, String team_password, String user_otp) throws SQLException
  {
    String query = "select * from team where team_password = '" + team_password.trim() + "'";
    Statement stmt = connection.createStatement();
    ResultSet result = stmt.executeQuery(query);
    String team_id = null;
    if (result.next())
    {
      team_id = result.getString("team_id");
    }
    if (team_id == null)
    {
      result.close();
      stmt.close();
      return false;
    }
    query = "select * from userinfo where email_id = '" + user_name.toLowerCase().trim() + "'";
    stmt = connection.createStatement();
    result = stmt.executeQuery(query);
    if (result.next())
    {
      String status = result.getString("status");
      if (status.equalsIgnoreCase("SUSPEND"))
      {
        result.close();
        stmt.close();
        return false;
      }
      if (!team_id.equals(result.getString("team_id")))
      {
        result.close();
        stmt.close();
        return false;
      }
      if (!user_otp.trim().equals(result.getString("otp")))
      {
        result.close();
        stmt.close();
        return false;
      }
    }
    else
    {
      result.close();
      stmt.close();
      return false;
    }
    result.close();
    stmt.close();
    return true;
  }

  public void setUserDetailsByEmailId(User user) throws SQLException
  {
    String team_id = null;
    String query = "select * from userinfo where email_id = '" + user.getEmailId().toLowerCase().trim() + "'";
    Statement stmt = connection.createStatement();
    ResultSet result = stmt.executeQuery(query);
    while (result.next())
    {
      user.setUserId(result.getString("user_id"));
      user.setFirstName(result.getString("first_name"));
      user.setLastName(result.getString("last_name"));
      user.setOtp(result.getString("otp"));
      team_id = result.getString("team_id");
    }
    result.close();
    stmt.close();
    TeamService service = new TeamService(connection);
    if (team_id == null)
    {
      System.out.println("Problem Email = " + user.getEmailId());
    }
    user.setTeam(service.getTeamDetailsById(team_id));
  }

  public void setAllUsersOFF() throws SQLException
  {
    String query = "update userinfo set status='OFF'";
    Statement stmt = connection.createStatement();
    stmt.executeUpdate(query);
    stmt.close();
  }

  public void setUserStatusON(User user) throws SQLException
  {
    String query = "update userinfo set status='ON' where user_id = " + user.getUserId().trim();
    Statement stmt = connection.createStatement();
    stmt.executeUpdate(query);
    stmt.close();
  }

  public void setUserStatusOFF(User user) throws SQLException
  {
    String query = "update userinfo set status='OFF' where user_id = " + user.getUserId().trim();
    Statement stmt = connection.createStatement();
    stmt.executeUpdate(query);
    stmt.close();
  }

  public void updateUserOTP(User user) throws SQLException
  {
    String query = "update userinfo set otp='" + user.getOtp().trim() + "' where user_id = " + user.getUserId().trim();
    Statement stmt = connection.createStatement();
    stmt.executeUpdate(query);
    stmt.close();
  }

  public void getUserOTP(User user) throws SQLException
  {
    String query = "select otp from userinfo where user_id = " + user.getUserId().trim();
    Statement stmt = connection.createStatement();
    ResultSet result = stmt.executeQuery(query);
    while (result.next())
    {
      user.setOtp(result.getString("otp"));
    }
    result.close();
    stmt.close();
  }

  public void getUserUniqueIDByEmailId(User user) throws SQLException
  {
    String query = "select user_id from userinfo where email_id= '" + user.getEmailId().trim() + "'";
    Statement stmt = connection.createStatement();
    ResultSet result = stmt.executeQuery(query);
    while (result.next())
    {
      user.setUserId(result.getString("user_id"));
    }
    result.close();
    stmt.close();
  }

  public String getUserFnameLnameByUserId(String user_id) throws SQLException
  {
    String user_complete_name = "";
    String query = "select first_name, last_name from userinfo where user_id = " + user_id.trim();
    Statement stmt = connection.createStatement();
    ResultSet result = stmt.executeQuery(query);
    while (result.next())
    {
      user_complete_name = user_complete_name + result.getString("first_name");
      user_complete_name = user_complete_name + " " + result.getString("last_name");
      break;
    }
    return user_complete_name;
  }
}
