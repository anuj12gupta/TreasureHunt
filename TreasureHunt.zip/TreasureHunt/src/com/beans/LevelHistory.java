package com.beans;

public class LevelHistory
{
  private String tran_id;
  private String team_level;
  private String cross_by;
  private String cross_date;
  private String cross_time;

  public String getTran_id()
  {
    return tran_id;
  }

  public void setTran_id(String tran_id)
  {
    this.tran_id = tran_id;
  }

  public String getTeam_level()
  {
    return team_level;
  }

  public void setTeam_level(String team_level)
  {
    this.team_level = team_level;
  }

  public String getCross_by()
  {
    return cross_by;
  }

  public void setCross_by(String cross_by)
  {
    this.cross_by = cross_by;
  }

  public String getCross_date()
  {
    return cross_date;
  }

  public void setCross_date(String cross_date)
  {
    this.cross_date = cross_date;
  }

  public String getCross_time()
  {
    return cross_time;
  }

  public void setCross_time(String cross_time)
  {
    this.cross_time = cross_time;
  }
}
