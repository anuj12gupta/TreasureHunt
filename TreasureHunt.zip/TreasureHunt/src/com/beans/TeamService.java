package com.beans;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TeamService
{
  private Connection connection;

  public TeamService(Connection connection)
  {
    this.connection = connection;
  }

  public Team getTeamDetailsById(String team_id) throws SQLException
  {
    String query = "select * from team where team_id = " + team_id.trim();
    Statement stmt = connection.createStatement();
    ResultSet result = stmt.executeQuery(query);
    Team team = null;
    while (result.next())
    {
      team = new Team();
      team.setTeamId(team_id);
      team.setTeamName(result.getString("team_name"));
      team.setTeamLevel(result.getString("team_level"));
    }
    return team;
  }

  public String getTeamNameById(String team_id) throws SQLException
  {
    String team_name = null;
    String query = "select team_name from team where team_id = " + team_id.trim();
    Statement stmt = connection.createStatement();
    ResultSet result = stmt.executeQuery(query);
    while (result.next())
    {
      team_name = result.getString("team_name");
    }
    return team_name;
  }

  public String getTeamLevelById(String team_id) throws SQLException
  {
    String team_level = null;
    String query = "select team_level from team where team_id = " + team_id.trim();
    Statement stmt = connection.createStatement();
    ResultSet result = stmt.executeQuery(query);
    while (result.next())
    {
      team_level = result.getString("team_level");
    }
    return team_level;
  }

  public List<String> getListOfTeamIds() throws SQLException
  {
    List<String> teamIdList = new ArrayList<String>();
    String query = "select team_id from team";
    Statement stmt = connection.createStatement();
    ResultSet result = stmt.executeQuery(query);
    while (result.next())
    {
      String team_id = result.getString("team_id");
      teamIdList.add(team_id);
    }
    return teamIdList;
  }

  public void updateTeamLevel(String team_id, int team_level) throws SQLException
  {
    String query = "update team set team_level = " + team_level + " where team_id = " + team_id.trim();
    Statement stmt = connection.createStatement();
    stmt.executeUpdate(query);
  }
}
