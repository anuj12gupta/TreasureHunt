package com.beans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TransactionService
{
  private Connection connection;

  public TransactionService(Connection connection)
  {
    this.connection = connection;
  }

  public int storeUserLevelUpTransaction(Transaction transaction) throws SQLException
  {
    String query = "insert into answer_transactions(team_id, user_id, ques_id, ans_date, ans_time) VALUES(?,?,?,?,?)";
    PreparedStatement prepStatement = connection.prepareStatement(query);
    prepStatement.setInt(1, Integer.parseInt(transaction.getUser().getTeam().getTeamId().trim()));
    prepStatement.setInt(2, Integer.parseInt(transaction.getUser().getUserId().trim()));
    prepStatement.setInt(3, Integer.parseInt(transaction.getUser().getTeam().getTeamLevel().trim()));
    prepStatement.setString(4, transaction.getAnswerDate().trim());
    prepStatement.setString(5, transaction.getAnswerTime().trim());
    return prepStatement.executeUpdate();
  }

  public List<LevelHistory> getTeamLevelHistory(String team_id) throws SQLException
  {
    int i = 0;
    List<LevelHistory> levelHistoryList = new ArrayList<LevelHistory>();
    String query = "select * from answer_transactions where team_id = " + team_id.trim() + " order by ques_id";
    Statement stmt = connection.createStatement();
    ResultSet result = stmt.executeQuery(query);
    UserService userService = new UserService(connection);
    while (result.next())
    {
      LevelHistory history = new LevelHistory();
      history.setTran_id(result.getString("tran_id"));
      history.setTeam_level(result.getString("ques_id"));
      history.setCross_date(result.getString("ans_date"));
      history.setCross_time(result.getString("ans_time"));
      int user_id = result.getInt("user_id");
      history.setCross_by(userService.getUserFnameLnameByUserId(Integer.toString(user_id)));
      i++;
      levelHistoryList.add(history);
    }
    for (; i < 10; i++)
    {
      LevelHistory history = new LevelHistory();
      history.setTran_id("ID#");
      history.setTeam_level(Integer.toString(i + 1));
      history.setCross_date("-");
      history.setCross_time("-");
      history.setCross_by("-");
      levelHistoryList.add(history);
    }
    return levelHistoryList;
  }
}
