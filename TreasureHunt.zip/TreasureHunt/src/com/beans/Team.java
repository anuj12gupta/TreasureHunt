package com.beans;

public class Team
{
  private String teamId;
  private String teamName;
  private String teamLevel;
  private String teamPassword;

  public String getTeamId()
  {
    return teamId;
  }

  public void setTeamId(String teamId)
  {
    this.teamId = teamId;
  }

  public String getTeamName()
  {
    return teamName;
  }

  public void setTeamName(String teamName)
  {
    this.teamName = teamName;
  }

  public String getTeamLevel()
  {
    return teamLevel;
  }

  public void setTeamLevel(String teamLevel)
  {
    this.teamLevel = teamLevel;
  }

  public String getTeamPassword()
  {
    return teamPassword;
  }

  public void setTeamPassword(String teamPassword)
  {
    this.teamPassword = teamPassword;
  }

}
