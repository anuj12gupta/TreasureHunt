package com.beans;

import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public abstract class MailFunction
{
  public static Session getSession()
  {
    Properties props = new Properties();
    // props.put("mail.smtp.ssl.enable", "true");
    // USCHAAPPSMTP
    // props.put("mail.smtp.host", "10.178.234.39"); // @ Main
    // props.put("mail.smtp.host", "10.178.234.39");
    // props.put("mail.smtp.host", "10.178.250.39"); // @ Backup;
    props.put("mail.smtp.host", "127.0.0.1");
    props.put("mail.smtp.socketFactory.port", "25");
    // props.put("mail.smtp.port", "25");
    // props.put("host",host);
    props.put("mail.smtp.connectiontimeout", "10000");
    props.put("mail.smtp.timeout", "10000");
    return (Session.getInstance(props));
  }

  public static void sendMail(String ccMailID, String toMailID, String mailSubject, String messageBody)
  {
    Message msg = new MimeMessage(getSession());
    try
    {
      InternetAddress address[];
      InternetAddress addressCC[];
      InternetAddress addressBCC[];
      msg.setFrom(new InternetAddress("treasure-hunt@firstdata.com"));
      address = InternetAddress.parse(toMailID);
      addressCC = InternetAddress.parse(ccMailID);
      addressBCC = InternetAddress.parse("anuj.gupta@firstdata.com");
      msg.setRecipients(Message.RecipientType.TO, address);
      msg.addRecipients(Message.RecipientType.CC, addressCC);
      msg.addRecipients(Message.RecipientType.BCC, addressBCC);
      msg.setSubject(mailSubject);
      msg.setSentDate(new Date());
      msg.setContent(messageBody, "text/html; charset=utf-8");

      Transport.send(msg);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }

  public static void main(String args[])
  {
    // System.out.println("Hello1");
    MailFunction.sendMail("anuj.gupta@firstdata.com", "", "Sub", "Body");
    // System.out.println("Hello");
  }
}
