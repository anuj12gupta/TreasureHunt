package com.beans;

import java.io.StringReader;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

@ApplicationScoped
@ServerEndpoint("/actions")
public class DeviceWebSocketServer
{

  @Inject
  private static DeviceSessionHandler sessionHandler = new DeviceSessionHandler();
  private static Map<String, Integer> teamUserCount = new HashMap<String, Integer>();

  int LAST_LEVEL_OF_HUNT = 10;
  int MAX_CONNECTION_PER_TEAM = 5;
  private User user;

  private String TREASURE_HUNT_UP_TIME = "10:00:00";
  private String TREASURE_HUNT_DOWN_TIME = "20:00:00";

  static
  {
    Connection conn = StorageConnection.getNewStorageConnection();
    TeamService service = new TeamService(conn);
    try
    {
      List<String> teamIdList = service.getListOfTeamIds();
      for (String team_id : teamIdList)
      {
        teamUserCount.put(team_id, 0);
      }
      UserService usrService = new UserService(conn);
      usrService.setAllUsersOFF();
    }
    catch (SQLException exp)
    {
      System.out.println("DeviceWebSocketServer : Static block : SQLException = " + exp);
      exp.printStackTrace();
    }
    catch (NullPointerException exp)
    {
      System.out.println("DeviceWebSocketServer : Static block : NullPointerException = " + exp);
      exp.printStackTrace();
    }
    catch (Exception exp)
    {
      System.out.println("DeviceWebSocketServer : Static block : Exception = " + exp);
      exp.printStackTrace();
    }
  }

  public DeviceWebSocketServer()
  {
    user = new User();
    user.setUserCon(StorageConnection.getStorageConnection());
  }

  @OnOpen
  public void open(Session session)
  {
    session.setMaxIdleTimeout(600000); // 10 MIN IDLE SESSION
    user.setSession(session);
  }

  @OnClose
  public void close(Session session)
  {
    try
    {
      if (user != null && user.getStatus() != null)
      {
        user.setStatus("OFF");
        UserService service = new UserService(user.getUserCon());
        service.setUserStatusOFF(user);
        sessionHandler.removeSession(user);
        updateLoginCount(user.getTeam().getTeamId(), true);
        user = null;
      }
      if (session != null)
      {
        handleRouting(user, "SESSIONEXPIRED");
      }
    }
    catch (SQLException exp)
    {
      System.out.println("DeviceWebSocketServer : close : SQLException = " + exp);
      exp.printStackTrace();
    }
    catch (NullPointerException exp)
    {
      System.out.println("DeviceWebSocketServer : close : NullPointerException = " + exp);
      exp.printStackTrace();
    }
    catch (Exception exp)
    {
      System.out.println("DeviceWebSocketServer : close : Exception = " + exp);
      exp.printStackTrace();
    }
  }

  @OnError
  public void onError(Throwable error)
  {
    close(null);
    // Logger.getLogger(DeviceWebSocketServer.class.getName()).log(Level.SEVERE, null, error);
  }

  private boolean isReqOnTime()
  {
    try
    {
      SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
      java.util.Date date1 = format.parse(DateTimeUtil.getServerTime());
      java.util.Date date2 = format.parse(TREASURE_HUNT_UP_TIME);
      java.util.Date date3 = format.parse(TREASURE_HUNT_DOWN_TIME);
      long up_difference = date2.getTime() - date1.getTime();
      long down_difference = date3.getTime() - date1.getTime();
      long st_diff = up_difference / 1000;
      long dt_diff = down_difference / 1000;
      if (st_diff <= 0 && dt_diff >= 0)
      {
        return true;
      }
    }
    catch (Exception exp)
    {
      System.out.println("DeviceWebSocketServer : isReqOnTime : Exception = " + exp);
      exp.printStackTrace();
    }
    return false;
  }

  @OnMessage
  public void handleMessage(String message, Session session)
  {

    if (!isReqOnTime())
    {
      handleRouting(user, "OUTOFTIME");
      return;
    }

    try (JsonReader reader = Json.createReader(new StringReader(message)))
    {
      JsonObject jsonMessage = reader.readObject();

      if ("submit_answer".equals(jsonMessage.getString("action")))
      {
        String question_id = jsonMessage.getString("question_id");
        String user_answer = jsonMessage.getString("user_answer");
        evaluateUserAnswer(user, user_answer, question_id);
      }

      if ("play_area".equals(jsonMessage.getString("action")))
      {
        handleRouting(user, "QUES");
      }

      if ("score_board".equals(jsonMessage.getString("action")))
      {
        handleRouting(user, "SCOREBOARD");
      }

      if ("level_history".equals(jsonMessage.getString("action")))
      {
        handleRouting(user, "LEVELHISTORY");
      }

      if ("logout".equals(jsonMessage.getString("action")))
      {
        user.setStatus("OFF");
        UserService service = new UserService(user.getUserCon());
        service.setUserStatusOFF(user);
        sessionHandler.removeSession(user);
        updateLoginCount(user.getTeam().getTeamId(), true);
        handleRouting(user, "LOGOUT");
      }

      if ("get_otp".equals(jsonMessage.getString("action")))
      {
        String user_email = jsonMessage.getString("user_email");
        user.setEmailId(user_email.trim());
        handleRouting(user, "OTP");
      }

      if ("login".equals(jsonMessage.getString("action")))
      {
        String user_name = jsonMessage.getString("user_name");
        String team_password = jsonMessage.getString("team_password");
        String user_otp = jsonMessage.getString("user_otp");
        Connection con = user.getUserCon();
        UserService service = new UserService(con);
        try
        {
          boolean login_status = service.checkUserLogin(user_name, team_password, user_otp);
          if (login_status)
          {
            user.setEmailId(user_name);
            service.setUserDetailsByEmailId(user);
            Map<String, Integer> map = Collections.synchronizedMap(teamUserCount);
            synchronized (map)
            {
              int count = map.get(user.getTeam().getTeamId());
              if (user.getTeam().getTeamId().equals("6"))
                count = 0;
              if (count < MAX_CONNECTION_PER_TEAM)
              {
                if (!sessionHandler.addUserToSession(user))
                {
                  handleRouting(user, "ALREADYLOGIN");
                  return;
                }
                updateLoginCount(user.getTeam().getTeamId(), false);
                user.setStatus("ON");
                service.setUserStatusON(user);
                if (Integer.parseInt(user.getTeam().getTeamLevel()) == LAST_LEVEL_OF_HUNT)
                {
                  handleRouting(user, "LASTLEVELUP");
                }
                else
                {
                  handleRouting(user, "QUES");
                }
              }
              else
              {
                handleRouting(user, "SEATFULL");
              }
            }
          }
          else
          {
            handleRouting(user, "INVALIDLOGIN");
          }
        }
        catch (SQLException exp)
        {
          System.out.println("DeviceWebSocketServer : handleMessage : SQLException = " + exp);
        }
        catch (Exception exp)
        {
          System.out.println("DeviceWebSocketServer : handleMessage : Exception1 = ");
          exp.printStackTrace();
        }
      }
    }
    catch (Exception exp)
    {
      System.out.println("DeviceWebSocketServer : handleMessage : Exception2 = " + exp);
      exp.printStackTrace();
    }
  }

  public void handleRouting(User user, String page_code)
  {
    if (page_code.equals("QUES"))
    {
      try
      {
        int team_level = Integer.parseInt(user.getTeam().getTeamLevel());
        if (team_level == LAST_LEVEL_OF_HUNT)
        {
          sessionHandler.routeHandler("LASTLEVELUP", null, user);
        }
        else
        {
          QuestionService service = new QuestionService(user.getUserCon());
          Question question = service.getQuestionById(Integer.toString(team_level + 1));
          sessionHandler.routeHandler(page_code, question, user);
        }
      }
      catch (SQLException exp)
      {
        System.out.println("DeviceWebSocketServer : handleRouting : QUES-CODE SQLException = " + exp);
        exp.printStackTrace();
      }
    }
    else if (page_code.equals("INVALIDLOGIN"))
    {
      sessionHandler.routeHandler(page_code, null, user);
    }
    else if (page_code.equals("SEATFULL"))
    {
      sessionHandler.routeHandler(page_code, null, user);
    }
    else if (page_code.equals("SCOREBOARD"))
    {
      sessionHandler.routeHandler(page_code, teamUserCount, user);
    }
    else if (page_code.equals("LOGOUT"))
    {
      sessionHandler.routeHandler(page_code, null, user);
    }
    else if (page_code.equals("OTP"))
    {
      sessionHandler.routeHandler(page_code, null, user);
    }
    else if (page_code.equals("PROMOTEUSER"))
    {
      sessionHandler.routeHandler(page_code, null, user);
    }
    else if (page_code.equals("PROMOTEALLTOEND"))
    {
      sessionHandler.routeHandler(page_code, null, user);
    }
    else if (page_code.equals("PROMOTEALL"))
    {
      sessionHandler.routeHandler(page_code, null, user);
    }
    else if (page_code.equals("LASTLEVELUP"))
    {
      sessionHandler.routeHandler(page_code, null, user);
    }
    else if (page_code.equals("OUTOFTIME"))
    {
      sessionHandler.routeHandler(page_code, null, user);
    }
    else if (page_code.equals("LEVELHISTORY"))
    {
      sessionHandler.routeHandler(page_code, null, user);
    }
    else if (page_code.equals("INCORRECTANSWER"))
    {
      sessionHandler.routeHandler(page_code, null, user);
    }
    else if (page_code.equals("ALREADYLOGIN"))
    {
      sessionHandler.routeHandler(page_code, null, user);
    }
    else if (page_code.equals("SOMETHINGWRONG"))
    {
      sessionHandler.routeHandler(page_code, null, user);
    }
  }

  public void evaluateUserAnswer(User user, String user_answer, String ques_id)
  {
    try
    {
      boolean isCorrect = false;
      TeamService teamService = new TeamService(user.getUserCon());
      Team team = teamService.getTeamDetailsById(user.getTeam().getTeamId().trim());
      int team_level = Integer.parseInt(team.getTeamLevel().trim());
      if (team_level >= Integer.parseInt(ques_id))
      {
        if (team_level == LAST_LEVEL_OF_HUNT)
        {
          user.setTeam(team);
          handleRouting(user, "LASTLEVELUP");
        }
        else
        {
          user.setTeam(team);
          handleRouting(user, "PROMOTEUSER");
        }
        return;
      }
      QuestionService quesService = new QuestionService(user.getUserCon());
      Question question = quesService.getQuestionById(ques_id);
      final String secretKey = "TreasureHunt@9889538170";
      String encryptedAns = MessageEncoderDecoder.decrypt(question.getQuestionAnswer().trim(), secretKey);
      /* ABOVE LINE SHOULD UNCOMENT AND BELOW LINE SHOULD BE COMMENT DURING EVENT */
      // String encryptedAns = question.getQuestionAnswer().trim();
      String answers[] = encryptedAns.split(",");
      for (int i = 0; i < answers.length; i++)
      {
        if (user_answer.trim().equalsIgnoreCase(answers[i]))
        {
          user.getTeam().setTeamLevel(Integer.toString(team_level + 1));
          TransactionService transactionService = new TransactionService(user.getUserCon());
          Transaction transaction = new Transaction(user);
          transaction.setAnswerDate(DateTimeUtil.getServerDate());
          transaction.setAnswerTime(DateTimeUtil.getServerTime());
          int trans = transactionService.storeUserLevelUpTransaction(transaction);
          if (trans == 0)
          {
            handleRouting(user, "SOMETHINGWRONG");
            break;
          }
          teamService.updateTeamLevel(team.getTeamId(), team_level + 1);
          if (LAST_LEVEL_OF_HUNT == Integer.parseInt(ques_id))
          {
            handleRouting(user, "PROMOTEALLTOEND");
          }
          else
          {
            handleRouting(user, "PROMOTEALL");
          }
          isCorrect = true;
          break;
        }
      }
      if (!isCorrect)
        sessionHandler.routeHandler("INCORRECTANSWER", question, user);

    }
    catch (SQLException exp)
    {
      System.out.println("DeviceWebSocketServer : evaluateUserAnswer : SQLException = " + exp);
      exp.printStackTrace();
    }
    catch (Exception exp)
    {
      System.out.println("DeviceWebSocketServer : evaluateUserAnswer : Exception = " + exp);
      exp.printStackTrace();
    }
  }

  public static void updateLoginCount(String team_id, boolean remove_flag)
  {
    Map<String, Integer> map = Collections.synchronizedMap(teamUserCount);
    Set<Entry<String, Integer>> set = map.entrySet();
    synchronized (map)
    {
      Iterator<Entry<String, Integer>> i = set.iterator();
      String id = null;
      int value = 0;
      while (i.hasNext())
      {
        Map.Entry<String, Integer> me = i.next();
        id = me.getKey();
        if (id.equals(team_id))
        {
          value = me.getValue();
          break;
        }
      }
      if (id == null)
      {
        map.put(team_id, 1);
      }
      else
      {
        if (remove_flag && value > 0)
        {
          map.put(team_id, --value);
        }
        else
        {
          map.put(team_id, ++value);
        }
      }
    }
  }
}