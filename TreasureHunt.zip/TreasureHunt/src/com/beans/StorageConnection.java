package com.beans;

import java.net.InetAddress;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.json.Json;
import javax.json.JsonObjectBuilder;

public abstract class StorageConnection
{
  public static Connection connection = null;
  /*
   * public static Connection getStorageConnection() { Connection connection = null; try {
   * 
   * Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); String msAccDB = null; msAccDB = "C:/ODC-CTR-UAT/Database/TreasureHunt.accdb";
   * 
   * String dbURL = "jdbc:ucanaccess://" + msAccDB;
   * 
   * connection = DriverManager.getConnection(dbURL); } catch (ClassNotFoundException cnfex) {
   * 
   * System.out.println("Problem in loading or " + "registering MS Access JDBC driver"); cnfex.printStackTrace(); } catch (SQLException sqlex) { sqlex.printStackTrace(); } return connection; }
   */

  public static synchronized Connection getStorageConnection()
  {

    try
    {
      if (connection == null)
      {

        Class.forName("org.sqlite.JDBC");
        // connection = DriverManager.getConnection("jdbc:sqlite:C:/ODC-CTR-UAT/Database/TreasureHunt.db");
        connection = DriverManager.getConnection("jdbc:sqlite:/opt/visionplus/TreasureHunt.db");
      }
    }
    catch (ClassNotFoundException cnfex)
    {
      System.out.println("Problem in loading or " + "registering MS Access JDBC driver");
      cnfex.printStackTrace();
    }
    catch (SQLException sqlex)
    {
      sqlex.printStackTrace();
    }
    return connection;
  }

  public static Connection getNewStorageConnection()
  {
    return getStorageConnection();
  }

  public static void returnConnection(Connection connection)
  {
    try
    {
      // connection.close();
    }
    catch (Exception exp)
    {
      System.out.println("Exception occured while closing connection");
    }
  }

  public static void getPCName() throws Exception
  {
    InetAddress ip = InetAddress.getLocalHost();

    System.out.println("Name + IP: " + ip.toString());
    System.out.println("Name:" + ip.getHostName());
    System.out.println("IP address: " + ip.getHostAddress());
    System.out.println("Full name: " + ip.getCanonicalHostName());
  }

  public static void main(String agrs[]) throws Exception
  {
    getPCName();
    System.out.println(getStorageConnection());
    /*
     * Connection connection = StorageConnection.getStorageConnection(); Statement stmt = connection.createStatement(); ResultSet result = stmt.executeQuery("SELECT * FROM USER_DETAILS");
     * while(result.next()) { System.out.println(result.getString("ID")); System.out.println(result.getString("FIRST_NAME")); System.out.println(result.getString("LAST_NAME"));
     * System.out.println(result.getString("USER_ROLE")); System.out.println(result.getString("USER_STATUS")); } System.out.println();
     */
    JsonObjectBuilder outer = Json.createObjectBuilder();
    JsonObjectBuilder jsonObject = Json.createObjectBuilder();
    // outer.add("", arg1)
    outer.add("spkConfig", jsonObject.build());
  }
}
