package com.beans;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class QuestionService
{
  private Connection connection;

  public QuestionService(Connection connection)
  {
    this.connection = connection;
  }

  public Question getQuestionById(String ques_id) throws SQLException
  {
    String query = "select * from questions where ques_id = " + ques_id.trim();
    Statement stmt = connection.createStatement();
    ResultSet result = stmt.executeQuery(query);
    Question question = null;
    while (result.next())
    {
      question = new Question();
      question.setQuesId(ques_id);
      question.setQuestionSrc(result.getString("question_src"));
      question.setQuestionAnswer(result.getString("question_answer"));
      question.setQuestionHint(result.getString("question_hint"));
    }
    return question;
  }
}
