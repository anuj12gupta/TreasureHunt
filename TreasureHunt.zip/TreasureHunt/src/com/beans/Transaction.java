package com.beans;

public class Transaction
{
  private User user;
  private String answerDate;
  private String answerTime;

  public Transaction(User user)
  {
    this.user = user;
  }

  public User getUser()
  {
    return user;
  }

  public void setUser(User user)
  {
    this.user = user;
  }

  public String getAnswerDate()
  {
    return answerDate;
  }

  public void setAnswerDate(String answerDate)
  {
    this.answerDate = answerDate;
  }

  public String getAnswerTime()
  {
    return answerTime;
  }

  public void setAnswerTime(String answerTime)
  {
    this.answerTime = answerTime;
  }
}
