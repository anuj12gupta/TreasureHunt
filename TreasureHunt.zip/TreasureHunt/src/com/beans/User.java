package com.beans;

import java.sql.Connection;

import javax.websocket.Session;

public class User
{
  private String userId;
  private String firstName;
  private String lastName;
  private String emailId;
  private String otp;
  private Team team;
  private String status;
  private Connection userCon;
  private Session session;

  public String getUserId()
  {
    return userId;
  }

  public void setUserId(String userId)
  {
    this.userId = userId;
  }

  public String getFirstName()
  {
    return firstName;
  }

  public void setFirstName(String firstName)
  {
    this.firstName = firstName;
  }

  public String getLastName()
  {
    return lastName;
  }

  public void setLastName(String lastName)
  {
    this.lastName = lastName;
  }

  public String getEmailId()
  {
    return emailId;
  }

  public void setEmailId(String emailId)
  {
    this.emailId = emailId;
  }

  public String getOtp()
  {
    return otp;
  }

  public void setOtp(String otp)
  {
    this.otp = otp;
  }

  public String getStatus()
  {
    return status;
  }

  public void setStatus(String status)
  {
    this.status = status;
  }

  public Team getTeam()
  {
    return team;
  }

  public void setTeam(Team team)
  {
    this.team = team;
  }

  public Connection getUserCon()
  {
    return userCon;
  }

  public void setUserCon(Connection userCon)
  {
    this.userCon = userCon;
  }

  public Session getSession()
  {
    return session;
  }

  public void setSession(Session session)
  {
    this.session = session;
  }

}
