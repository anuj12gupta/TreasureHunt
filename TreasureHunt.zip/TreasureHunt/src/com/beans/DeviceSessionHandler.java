package com.beans;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.enterprise.context.ApplicationScoped;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.spi.JsonProvider;
import javax.websocket.Session;

@ApplicationScoped
public class DeviceSessionHandler
{
  private final Set<User> sessionUsers = new HashSet<>();

  public boolean addUserToSession(User user)
  {
    boolean found_flag = false;
    Iterator<User> itr = sessionUsers.iterator();
    while (itr.hasNext())
    {
      User sessionUser = itr.next();
      if (sessionUser.getUserId().trim().equals(user.getUserId().trim()))
      {
        found_flag = true;
      }
    }
    if (!found_flag)
      sessionUsers.add(user);
    return !found_flag;
  }

  public void removeSessionUser(User user)
  {
    sessionUsers.remove(user);
  }

  public JsonObject getQuestionPageJson(Question question, boolean isNew)
  {
    JsonProvider provider = JsonProvider.provider();
    JsonObjectBuilder builder = provider.createObjectBuilder();
    if (!isNew)
    {
      builder.add("page", "INCORRECTANSWER");
    }
    else
    {
      builder.add("page", "QUES");
    }
    builder.add("level", question.getQuesId()).add("source", question.getQuestionSrc())
        .add("hint", question.getQuestionHint() != null ? question.getQuestionHint().trim().length() != 0 ? question.getQuestionHint().trim() : "N" : "N");
    JsonObject questionPageJson = builder.build();
    return questionPageJson;
  }

  public JsonObject getLoginPageJson(boolean is_with_error, String message)
  {
    JsonProvider provider = JsonProvider.provider();
    String page_code = is_with_error ? "LOGINERROR" : "LOGIN";
    JsonObject loginPageJson = provider.createObjectBuilder().add("page", page_code).add("message", message == null ? "" : message).build();
    return loginPageJson;
  }

  public JsonObject getLevelHistoryPageJson(User user)
  {
    JsonProvider provider = JsonProvider.provider();
    JsonObjectBuilder builder = provider.createObjectBuilder();
    builder.add("page", "LEVELHISTORY");
    TransactionService service = new TransactionService(user.getUserCon());
    try
    {
      List<LevelHistory> historyList = service.getTeamLevelHistory(user.getTeam().getTeamId());
      historyList.stream().forEach(history ->
      {
        builder.add("L" + history.getTeam_level(), history.getTeam_level());
        builder.add("CROSSBY" + history.getTeam_level(), history.getCross_by());
        builder.add("CROSSDATE" + history.getTeam_level(), history.getCross_date());
        builder.add("CROSSTIME" + history.getTeam_level(), history.getCross_time());
      });
    }
    catch (SQLException exp)
    {
      System.out.println("DeviceSessionHandler : getLevelHistoryPageJson : SQLException = " + exp);
      exp.printStackTrace();
    }
    JsonObject levelHistoryBoardJson = builder.build();
    return levelHistoryBoardJson;
  }

  public JsonObject getScoreBoardPageJson(User user, Map<String, Integer> score_board_map)
  {
    JsonProvider provider = JsonProvider.provider();
    Set<Entry<String, Integer>> set = score_board_map.entrySet();

    JsonObjectBuilder builder = provider.createObjectBuilder();
    builder.add("page", "SCOREBOARD");
    Iterator<Entry<String, Integer>> i = set.iterator();
    String id = null;
    TeamService service = new TeamService(user.getUserCon());
    try
    {
      int seq = 0;
      while (i.hasNext())
      {
        seq++;
        Map.Entry<String, Integer> me = i.next();
        id = me.getKey();
        String team_name = service.getTeamNameById(id);
        if (team_name.equalsIgnoreCase("THUNDER CLUB") && !(user.getTeam().getTeamId().equals("6")))
          continue;
        String jsonValue = team_name + "@" + service.getTeamLevelById(id);
        builder.add("t" + Integer.toString(seq), jsonValue);
      }
    }
    catch (SQLException exp)
    {
      System.out.println("DeviceSessionHandler : getScoreBoardPageJson : SQLException = " + exp);
      exp.printStackTrace();
    }
    JsonObject scoreBoardJson = builder.build();
    return scoreBoardJson;
  }

  public JsonObject getSentOTPPageJson(String message)
  {
    JsonProvider provider = JsonProvider.provider();
    JsonObject loginPageJson = provider.createObjectBuilder().add("page", "OTPSENT").add("message", message).build();
    return loginPageJson;
  }

  public JsonObject getSessionExpiredPageJson()
  {
    JsonProvider provider = JsonProvider.provider();
    JsonObject loginPageJson = provider.createObjectBuilder().add("page", "SESSIONEXPIRED").build();
    return loginPageJson;
  }

  public JsonObject getEndPageJson()
  {
    JsonProvider provider = JsonProvider.provider();
    JsonObject loginPageJson = provider.createObjectBuilder().add("page", "ENDPAGE").build();
    return loginPageJson;
  }

  private void refreshUserSession(User user, JsonObject message)
  {
    sendToSession(user.getSession(), message);
  }

  public void routeHandler(String page_code, Object obj, User user)
  {
    if (page_code.equals("QUES"))
    {
      Question ques = (Question) obj;
      JsonObject pageJson = getQuestionPageJson(ques, true);
      refreshUserSession(user, pageJson);
    }
    else if (page_code.equals("INCORRECTANSWER"))
    {
      Question ques = (Question) obj;
      JsonObject pageJson = getQuestionPageJson(ques, false);
      refreshUserSession(user, pageJson);
    }
    else if (page_code.equals("INVALIDLOGIN"))
    {
      String message = "Invalid Login Credentials";
      JsonObject pageJson = getLoginPageJson(true, message);
      refreshUserSession(user, pageJson);
      if (user != null || user.getUserId() != null)
        removeSession(user);
      user = null;
    }
    else if (page_code.equals("SEATFULL"))
    {
      String message = "Maximum allowed users from a time is already playing, Please visit again after sometime";
      JsonObject pageJson = getLoginPageJson(true, message);
      refreshUserSession(user, pageJson);
      removeSession(user);
      user = null;
    }
    else if (page_code.equals("SCOREBOARD"))
    {
      Map<String, Integer> score_board_map = (Map<String, Integer>) obj;
      JsonObject pageJson = getScoreBoardPageJson(user, score_board_map);
      refreshUserSession(user, pageJson);
    }
    else if (page_code.equals("OTP"))
    {
      String message = null;
      JsonObject pageJson = null;
      if (sendOTPToUserViaMail(user))
      {
        message = "OTP is sent to registered email id. Please check your inbox or spam folder";
        pageJson = getSentOTPPageJson(message);
      }
      else
      {
        message = "Email Id is not registered in Treasure Hunt database";
        pageJson = getLoginPageJson(true, message);
      }
      refreshUserSession(user, pageJson);
      removeSession(user);
      user = null;
    }
    else if (page_code.equals("PROMOTEALL"))
    {
      promoteAll(user);
    }
    else if (page_code.equals("PROMOTEUSER"))
    {
      promoteUser(user);
    }
    else if (page_code.equals("PROMOTEALLTOEND"))
    {
      promoteAllToEnd(user);
    }
    else if (page_code.equals("LASTLEVELUP"))
    {
      JsonObject pageJson = getEndPageJson();
      refreshUserSession(user, pageJson);
    }
    else if (page_code.equals("LOGOUT"))
    {
      JsonObject pageJson = getLoginPageJson(false, null);
      refreshUserSession(user, pageJson);
      removeSession(user);
      user = null;
    }
    else if (page_code.equals("SESSIONEXPIRED"))
    {
      JsonObject pageJson = getSessionExpiredPageJson();
      refreshUserSession(user, pageJson);
      removeSession(user);
      user = null;
    }
    else if (page_code.equals("OUTOFTIME"))
    {
      String message = "Teasure Hunt is open for players from 10 AM to 8 PM.";
      JsonObject pageJson = getLoginPageJson(true, message);
      refreshUserSession(user, pageJson);
      removeSession(user);
      user = null;
    }
    else if (page_code.equals("LEVELHISTORY"))
    {
      JsonObject pageJson = getLevelHistoryPageJson(user);
      refreshUserSession(user, pageJson);
    }
    else if (page_code.equals("ALREADYLOGIN"))
    {
      String message = "You are already login into the system !!!";
      JsonObject pageJson = getLoginPageJson(true, message);
      refreshUserSession(user, pageJson);
      user = null;
    }
    else if (page_code.equals("SOMETHINGWRONG"))
    {
      String message = "Your Answer is correct, but database issue found. Please check with Thunder Club Team !!!";
      JsonObject pageJson = getLoginPageJson(true, message);
      refreshUserSession(user, pageJson);
      user = null;
    }

  }

  public void promoteAll(User user)
  {
    try
    {
      QuestionService quesService = new QuestionService(user.getUserCon());
      int ques_id = Integer.parseInt(user.getTeam().getTeamLevel().trim()) + 1;
      Question question = quesService.getQuestionById(Integer.toString(ques_id));
      JsonObject pageJson = getQuestionPageJson(question, true);
      Iterator<User> itr = sessionUsers.iterator();
      while (itr.hasNext())
      {
        User sessionUser = itr.next();
        if (sessionUser.getTeam().getTeamId().trim().equals(user.getTeam().getTeamId().trim()))
        {
          sessionUser.setTeam(user.getTeam());
          refreshUserSession(sessionUser, pageJson);
        }
      }
    }
    catch (Exception exp)
    {
      System.out.println("DeviceSessionHandler : promoteAll : Exception = " + exp);
      exp.printStackTrace();
    }
  }

  public void promoteUser(User user)
  {
    try
    {
      QuestionService quesService = new QuestionService(user.getUserCon());
      Question question = quesService.getQuestionById(user.getTeam().getTeamId().trim());
      JsonObject pageJson = getQuestionPageJson(question, true);
      refreshUserSession(user, pageJson);
    }
    catch (Exception exp)
    {
      System.out.println("DeviceSessionHandler : promoteUser : Exception = " + exp);
      exp.printStackTrace();
    }
  }

  public void promoteAllToEnd(User user)
  {
    try
    {
      JsonObject pageJson = getEndPageJson();
      Iterator<User> itr = sessionUsers.iterator();
      while (itr.hasNext())
      {
        User sessionUser = itr.next();
        if (sessionUser.getTeam().getTeamId().trim().equals(user.getTeam().getTeamId().trim()))
        {
          sessionUser.setTeam(user.getTeam());
          refreshUserSession(sessionUser, pageJson);
        }
      }
    }
    catch (Exception exp)
    {
      System.out.println("DeviceSessionHandler : promoteAllToEnd : Exception = " + exp);
      exp.printStackTrace();
    }
  }

  public boolean sendOTPToUserViaMail(User user)
  {
    UserService service = new UserService(user.getUserCon());
    try
    {
      service.getUserUniqueIDByEmailId(user);
      if (user.getUserId() == null)
        return false;
      service.getUserOTP(user);
      if (user.getOtp() == null || user.getOtp().isEmpty() || user.getOtp().length() == 0)
      {
        user.setOtp(getSystemGeneratedOTP());
        service.updateUserOTP(user);
      }
      MailFunction.sendMail("", user.getEmailId(), "Treasure Hunt Login OTP", "Hi User, <br/><br/> Your OTP to login on Treasure Hunt is " + user.getOtp());
    }
    catch (Exception exp)
    {
      System.out.println("DeviceSessionHandler : sendOTPToUserViaMail : Exception = " + exp);
      exp.printStackTrace();
      return false;
    }
    return true;
  }

  public String getSystemGeneratedOTP()
  {
    Random r = new Random();
    int low = 100;
    int high = 1000;
    int result1 = r.nextInt(high - low) + low;
    int result2 = r.nextInt(high - low) + low;
    return Integer.toString(result1) + result2;
  }

  public Set<User> getSessionUsers()
  {
    return sessionUsers;
  }

  public boolean isUserExist(User user)
  {
    Iterator<User> itr = sessionUsers.iterator();
    while (itr.hasNext())
    {
      User sessionUser = itr.next();
      if (sessionUser.getUserId().trim().equalsIgnoreCase(user.getUserId().trim()))
      {
        return true;
      }
    }
    return false;
  }

  public void removeSession(User user)
  {
    try
    {
      if (user == null || user.getUserId() == null)
        return;
      Set<User> syncSet = Collections.synchronizedSet(sessionUsers);
      synchronized (syncSet)
      {
        Iterator<User> itr = syncSet.iterator();
        while (itr.hasNext())
        {
          User sessionUser = itr.next();
          if (sessionUser.getUserId().trim().equalsIgnoreCase(user.getUserId().trim()))
          {
            UserService service = new UserService(user.getUserCon());
            service.setUserStatusOFF(user);
            itr.remove();
          }
        }
      }
    }
    catch (SQLException exp)
    {
      System.out.println("DeviceSessionHandler : removeSession : Exception = " + exp);
      exp.printStackTrace();
    }
  }

  private void sendToSession(Session session, JsonObject message)
  {
    try
    {
      session.getBasicRemote().sendText(message.toString());
    }
    catch (IOException exp)
    {
      Logger.getLogger(DeviceSessionHandler.class.getName()).log(Level.SEVERE, null, exp);
      System.out.println("DeviceSessionHandler : sendToSession : Exception = " + exp);
      exp.printStackTrace();
    }
  }
}